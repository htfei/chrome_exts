var db = openDatabase('m3u_db', '1.0', 'I can rss everthing !', 2 * 1024 * 1024);

db.transaction(function (tx) {
    //新建表
    tx.executeSql('CREATE TABLE IF NOT EXISTS m3u (uri PRIMARY KEY,title,group_title,logo,duration,timeline,uri_domain,class,enable,flag,flag2,flag3)');
    tx.executeSql('CREATE TABLE IF NOT EXISTS domain (domain PRIMARY KEY,ip,failed_rate,last_ping_status,last_ping,last_ping_ttl,avg_ping,last_succ_time,last_failed_time,class,enable,flag,flag2,flag3)');
});

//储存rss到websql
function list2websql(list) {
    //console.log(list);
    console.time('run');
    db.transaction(function (tx) {
        for (i = 0; i < list.length; i++) {
            tx.executeSql('INSERT OR REPLACE INTO m3u (uri,title,group_title,logo,duration,timeline,uri_domain,class,enable,flag,flag2,flag3) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
                list[i],
                null,
                function (tx, error) {
                    console.timeEnd('run');
                    console.error(error);
                    alert('导入m3u失败! Error: ' + error.message)
                });
            tx.executeSql('INSERT OR REPLACE INTO domain (domain) VALUES (?)',
                [list[i][6]],
                null,
                function (tx, error) {
                    console.timeEnd('run');
                    console.error(error);
                    alert('导入domain失败! Error: ' + error.message)
                });
        }
        alert('导入成功！');
    });
}

let parser;
//导入表单文件到localStorage，并刷新页面
document.getElementById('loadfile').onchange = function jsReadFiles() {
    if (this.files.length) {
        var file = this.files[0];
        var reader = new FileReader();
        reader.onload = function () {
            //console.log(this.result);

            parser = new m3u8Parser.Parser();

            // //例：自定义解析自定义的头部标签
            // parser.addParser({
            //     expression: /^#VOD-FRAMERATE/,
            //     customType: 'framerate',
            //     dataParser: function (line) {
            //         return parseFloat(line.split(':')[1]);
            //     }
            // });
            // //例：自定义解析自定义的seg标签
            // parser.addParser({
            //     expression: /#VOD-TIMING/,
            //     customType: 'vodTiming',
            //     segment: true
            // });
            //例：自定义解析内置标签（如#EXTINF）需先映射
            parser.addTagMapper({
                expression: /#EXTINF/,
                map(line) {
                    return `#MAP-EXTINF:${line}`;
                }
            });
            parser.addParser({
                expression: /#MAP-EXTINF/,
                customType: 'map_extinf',
                segment: true,
                dataParser: function (line) {
                    return {
                        "logo": (a = line.match(/logo="(.*?)"/)) ? a[1] : null,
                        "group_title": (a = line.match(/group-title="(.*?)"/)) ? a[1] : null,
                        "title": line.split(',')[1],
                    };
                }
            });

            parser.push(this.result);
            parser.end();
            //console.log(parser);
            ////console.log(parser.manifest.custom.framerate);
            ////console.log(parser.manifest.segments[0].custom.vodTiming);
            //console.log(parser.manifest.segments[0].custom.map_extinf);

            var dblist = [];
            var seglist = parser.manifest.segments;
            $('#table').bootstrapTable('append', seglist);
            
            for (i = 0; i < seglist.length; i++) {
                //提取domian
                var uri_domain = seglist[i].uri;
                //console.log(uri_domain);
                if (uri_domain.indexOf("[") > -1) {
                    uri_domain = uri_domain.match("\\[(.*?)\\]")[1];
                } else {
                    uri_domain = uri_domain.split('/')[2].split(':')[0];
                }

                //必须和插入顺序对应：uri,title,group_title,logo,duration,timeline,uri_domain,class,enable,flag,flag2,flag3
                dblist.push([
                    seglist[i].uri || '',
                    seglist[i].custom.map_extinf.title || '',
                    seglist[i].custom.map_extinf.group_title || '',
                    seglist[i].custom.map_extinf.logo || '',
                    seglist[i].duration || -1,
                    seglist[i].timeline || 0,
                    uri_domain,
                    0, 1, 0, 0, 0]);

                if (i == seglist.length - 1) {
                    list2websql(dblist);
                }
            }
        };
        reader.readAsText(file);
    }
};



function picFormatter(value) {
    return "<img src='" + value + "' class='img-rounded img-responsive'>"
}

# ZY-Player-Chrome-Extensions-V3

一键搜索全网视频资源，直接在线观看!

视频地址一般为m3u8，PC端建议安装chrome插件Native HLS Playback配合使用，手机端可直接播放（如kiwi浏览器）

## TODO

界面优化（主要手机端适配）
收藏功能
资源站管理
订阅功能
